cd drupal
tar cvf web.tar web
mv web.tar /var/www

