source ./jsonval2
cat branches.json | jsonValue title field_ynumber
