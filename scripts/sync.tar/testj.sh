source ~/ystart/scripts/dev.get.cid.sh
source ~/ystart/scripts/dev.get.sid.sh
source ~/ystart/scripts/dev.get.sync.sh
echo $sid $cid $uuid