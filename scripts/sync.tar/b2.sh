source ./get.key.sh
cat branches.json | get_key 907