tar -xf sync.tar -C ~/ystart/sync
